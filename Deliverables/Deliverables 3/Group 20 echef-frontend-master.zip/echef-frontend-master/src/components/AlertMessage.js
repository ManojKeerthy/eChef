"use strict";

import Styled from "styled-components";

export const AlertMessage = Styled.div`
    text-align: center;
    color: red;
    margin-top: 10px;
    font-weight: bold;
`;